@echo off
title Empadas da Bia Web
echo Iniciando Empadas da Bia Web... (o MySQL precisa estar ligado)
echo Quando aparecer "Started EmpadasWebApplication", abra http://localhost:8080
cd /d "%~dp0"
call mvnw.cmd spring-boot:run
pause
