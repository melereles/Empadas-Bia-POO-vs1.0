package br.com.empadasdabia.empadasweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpadasWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpadasWebApplication.class, args);
	}

}
