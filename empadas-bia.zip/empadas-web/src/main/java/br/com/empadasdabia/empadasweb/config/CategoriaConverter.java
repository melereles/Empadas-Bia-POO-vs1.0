package br.com.empadasdabia.empadasweb.config;

import br.com.empadasdabia.empadasweb.model.Categoria;
import br.com.empadasdabia.empadasweb.service.CategoriaService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

/**
 * Converte o valor do <select name="categoria"> (o id, em texto) na Categoria.
 * Passa pelo Service, como todo acesso a dados vindo da camada web.
 */
@Component
public class CategoriaConverter implements Converter<String, Categoria> {

    private final CategoriaService categoriaService;

    public CategoriaConverter(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @Override
    public Categoria convert(String id) {
        if (id == null || id.isBlank()) {
            return null;
        }
        return categoriaService.buscarPorId(Long.valueOf(id.trim()));
    }
}
