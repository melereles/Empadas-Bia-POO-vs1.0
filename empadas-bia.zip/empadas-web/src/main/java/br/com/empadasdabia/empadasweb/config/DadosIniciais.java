package br.com.empadasdabia.empadasweb.config;

import br.com.empadasdabia.empadasweb.model.Categoria;
import br.com.empadasdabia.empadasweb.model.Cliente;
import br.com.empadasdabia.empadasweb.model.Pedido;
import br.com.empadasdabia.empadasweb.model.Produto;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import br.com.empadasdabia.empadasweb.repository.CategoriaRepository;
import br.com.empadasdabia.empadasweb.repository.ClienteRepository;
import br.com.empadasdabia.empadasweb.repository.PedidoRepository;
import br.com.empadasdabia.empadasweb.repository.ProdutoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Carrega os mesmos dados de exemplo do projeto Swing na primeira execução
 * (só quando o banco está vazio). Desligue com app.dados-exemplo=false.
 * As datas dos pedidos são relativas ao momento da carga, para o painel mostrar dados "de hoje".
 */
@Component
@ConditionalOnProperty(name = "app.dados-exemplo", havingValue = "true", matchIfMissing = true)
public class DadosIniciais implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DadosIniciais.class);

    private final CategoriaRepository categoriaRepository;
    private final ProdutoRepository produtoRepository;
    private final ClienteRepository clienteRepository;
    private final PedidoRepository pedidoRepository;

    public DadosIniciais(CategoriaRepository categoriaRepository, ProdutoRepository produtoRepository,
                         ClienteRepository clienteRepository, PedidoRepository pedidoRepository) {
        this.categoriaRepository = categoriaRepository;
        this.produtoRepository = produtoRepository;
        this.clienteRepository = clienteRepository;
        this.pedidoRepository = pedidoRepository;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (categoriaRepository.count() > 0 || clienteRepository.count() > 0) {
            return;
        }
        log.info("Banco vazio: carregando dados de exemplo da Empadas da Bia...");

        Categoria salgadas = categoriaRepository.save(new Categoria("Empadas Salgadas", "Empadas com recheios salgados"));
        Categoria doces = categoriaRepository.save(new Categoria("Empadas Doces", "Empadas com recheios doces"));
        Categoria combos = categoriaRepository.save(new Categoria("Combos", "Kits com várias empadas"));
        categoriaRepository.save(new Categoria("Outros", "Bebidas e demais itens"));

        Produto frango = produto("Empada de Frango", "Frango desfiado temperado com cheiro-verde.", "8.00", true, "empada-frango.png", salgadas);
        Produto catupiry = produto("Empada de Frango com Catupiry", "Frango desfiado com o cremoso catupiry.", "9.00", true, "empada-frango-catupiry.png", salgadas);
        Produto palmito = produto("Empada de Palmito", "Palmito macio em molho branco.", "8.50", true, "empada-palmito.png", salgadas);
        Produto bacon = produto("Empada de Bacon", "Bacon crocante com queijo.", "9.00", true, "empada-bacon.png", salgadas);
        Produto camarao = produto("Empada de Camarão", "Camarão refogado com tomate e temperos.", "12.00", true, "empada-camarao.png", salgadas);
        Produto doceLeite = produto("Empada Doce de Leite", "Massa doce recheada com doce de leite.", "9.00", true, "empada-doce-de-leite.png", doces);
        Produto chocolate = produto("Empada de Chocolate", "Recheio cremoso de chocolate com granulado.", "9.00", true, "empada-chocolate.png", doces);
        produto("Empada Romeu e Julieta", "Queijo minas com goiabada.", "9.50", false, "empada-romeu-julieta.png", doces);
        Produto combo = produto("Combo Família (10 unidades)", "10 empadas à escolha entre salgadas e doces.", "80.00", true, "combo-familia.png", combos);

        Cliente ana = cliente("Ana Souza", "47998123344", "ana.souza@email.com", "89201000", "Rua das Palmeiras", "120", "Centro", "Joinville");
        Cliente carlos = cliente("Carlos Mendes", "47996542210", "carlos.m@email.com", "89204000", "Rua Max Colin", "455", "América", "Joinville");
        Cliente juliana = cliente("Juliana Rocha", "47991338890", "juliana.rocha@email.com", "89216100", "Rua Ottokar Doerffel", "980", "Glória", "Joinville");
        Cliente pedro = cliente("Pedro Alves", "47988771020", null, "89222000", "Rua Tuiuti", "77", "Bom Retiro", "Joinville");
        Cliente mariana = cliente("Mariana Lima", "47997024455", "mari.lima@email.com", "89220000", "Rua Iririú", "310", "Costa e Silva", "Joinville");
        Cliente rafael = cliente("Rafael Costa", "47992887731", "rafael.costa@email.com", "89210000", "Rua Monsenhor Gercino", "1500", "Itaum", "Joinville");
        Cliente beatriz = cliente("Beatriz Nunes", "47995416602", "bia.nunes@email.com", "89245000", "Rua XV de Novembro", "33", "Centro", "Araquari");
        Cliente lucas = cliente("Lucas Ferreira", "47993601188", null, "89221000", "Rua Blumenau", "845", "Saguaçu", "Joinville");

        LocalDateTime agora = LocalDateTime.now().withNano(0);
        pedido(carlos, agora.minusDays(9), StatusPedido.ENTREGUE, null, frango, 6, doceLeite, 4);
        pedido(juliana, agora.minusDays(8), StatusPedido.ENTREGUE, null, catupiry, 5, bacon, 5);
        pedido(mariana, agora.minusDays(7), StatusPedido.ENTREGUE, "Festa de aniversário", combo, 1);
        pedido(ana, agora.minusDays(6), StatusPedido.ENTREGUE, null, frango, 10, catupiry, 10);
        pedido(rafael, agora.minusDays(5), StatusPedido.CANCELADO, "Cliente desistiu", camarao, 4);
        pedido(lucas, agora.minusDays(4), StatusPedido.ENTREGUE, null, frango, 8, chocolate, 4);
        pedido(pedro, agora.minusDays(3), StatusPedido.ENTREGUE, null, catupiry, 6, doceLeite, 6);
        pedido(beatriz, agora.minusDays(2), StatusPedido.ENTREGUE, "Retirada no balcão", combo, 2);
        pedido(ana, agora.minusDays(2), StatusPedido.ENTREGUE, null, frango, 5);
        pedido(rafael, agora.minusDays(1), StatusPedido.ENTREGUE, null, palmito, 4, bacon, 4);
        pedido(mariana, agora.minusDays(1), StatusPedido.CANCELADO, null, doceLeite, 3, chocolate, 3);
        pedido(pedro, agora.minusDays(1), StatusPedido.ENTREGUE, null, frango, 2, bacon, 2);
        pedido(juliana, agora.minusMinutes(90), StatusPedido.ENTREGUE, null, combo, 1);
        pedido(carlos, agora.minusMinutes(60), StatusPedido.PENDENTE, null, frango, 6, catupiry, 6);
        pedido(ana, agora.minusMinutes(30), StatusPedido.PENDENTE, "Entregar após as 18h", frango, 3, palmito, 2, doceLeite, 2);

        log.info("Dados de exemplo carregados: 4 categorias, 9 produtos, 8 clientes e 15 pedidos.");
    }

    private Produto produto(String nome, String descricao, String preco, boolean ativo, String imagem, Categoria categoria) {
        Produto p = new Produto();
        p.setNome(nome);
        p.setDescricao(descricao);
        p.setPreco(new BigDecimal(preco));
        p.setAtivo(ativo);
        p.setImagem("/img/produtos/" + imagem);
        p.setCategoria(categoria);
        return produtoRepository.save(p);
    }

    private Cliente cliente(String nome, String telefone, String email, String cep, String logradouro,
                            String numero, String bairro, String cidade) {
        Cliente c = new Cliente();
        c.setNome(nome);
        c.setTelefone(telefone);
        c.setEmail(email);
        c.setCep(cep);
        c.setLogradouro(logradouro);
        c.setNumero(numero);
        c.setBairro(bairro);
        c.setCidade(cidade);
        return clienteRepository.save(c);
    }

    /** itens = produto, quantidade, produto, quantidade... */
    private void pedido(Cliente cliente, LocalDateTime data, StatusPedido status, String observacao, Object... itens) {
        Pedido p = new Pedido();
        p.setCliente(cliente);
        p.setDataPedido(data);
        p.setStatus(status);
        p.setObservacao(observacao);
        List<Object> lista = List.of(itens);
        for (int i = 0; i < lista.size(); i += 2) {
            p.adicionarItem((Produto) lista.get(i), (Integer) lista.get(i + 1));
        }
        pedidoRepository.save(p);
    }
}
