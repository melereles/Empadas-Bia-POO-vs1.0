package br.com.empadasdabia.empadasweb.config;

import br.com.empadasdabia.empadasweb.service.ImagemService;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/** Publica as fotos enviadas pelo cadastro de produto em /uploads/**. */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final ImagemService imagemService;

    public WebConfig(ImagemService imagemService) {
        this.imagemService = imagemService;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(imagemService.getPasta().toUri().toString());
    }
}
