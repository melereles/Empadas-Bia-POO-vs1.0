package br.com.empadasdabia.empadasweb.controller;

import br.com.empadasdabia.empadasweb.model.Categoria;
import br.com.empadasdabia.empadasweb.service.CategoriaService;
import br.com.empadasdabia.empadasweb.service.RegraNegocioException;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Recebe as requisições de /categorias, chama o CategoriaService e escolhe a tela. */
@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    private final CategoriaService categoriaService;

    public CategoriaController(CategoriaService categoriaService) {
        this.categoriaService = categoriaService;
    }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "categorias/lista";
    }

    @GetMapping("/nova")
    public String nova(Model model) {
        model.addAttribute("categoria", new Categoria());
        return "categorias/form";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("categoria", categoriaService.buscarPorId(id));
        return "categorias/form";
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("categoria") Categoria categoria, BindingResult erros,
                         Model model, RedirectAttributes avisos) {
        if (erros.hasErrors()) {
            return "categorias/form";
        }
        try {
            boolean nova = categoria.getId() == null;
            Categoria salva = categoriaService.salvar(categoria);
            avisos.addFlashAttribute("sucesso", "Categoria \"" + salva.getNome() + "\" "
                    + (nova ? "cadastrada" : "atualizada") + " com sucesso.");
            return "redirect:/categorias";
        } catch (RegraNegocioException e) {
            model.addAttribute("erro", e.getMessage());
            return "categorias/form";
        }
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes avisos) {
        try {
            categoriaService.excluir(id);
            avisos.addFlashAttribute("sucesso", "Categoria excluída.");
        } catch (RegraNegocioException e) {
            avisos.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/categorias";
    }
}
