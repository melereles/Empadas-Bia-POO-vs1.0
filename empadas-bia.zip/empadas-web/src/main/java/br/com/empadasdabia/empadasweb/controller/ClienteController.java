package br.com.empadasdabia.empadasweb.controller;

import br.com.empadasdabia.empadasweb.model.Cliente;
import br.com.empadasdabia.empadasweb.service.ClienteService;
import br.com.empadasdabia.empadasweb.service.RegraNegocioException;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Recebe as requisições de /clientes e chama o ClienteService. */
@Controller
@RequestMapping("/clientes")
public class ClienteController {

    private final ClienteService clienteService;

    public ClienteController(ClienteService clienteService) {
        this.clienteService = clienteService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String busca, Model model) {
        model.addAttribute("clientes", clienteService.listar(busca));
        model.addAttribute("busca", busca);
        return "clientes/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        model.addAttribute("cliente", new Cliente());
        return "clientes/form";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        model.addAttribute("cliente", clienteService.buscarPorId(id));
        return "clientes/form";
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("cliente") Cliente cliente, BindingResult erros,
                         Model model, RedirectAttributes avisos) {
        if (erros.hasErrors()) {
            return "clientes/form";
        }
        try {
            boolean novo = cliente.getId() == null;
            Cliente salvo = clienteService.salvar(cliente);
            avisos.addFlashAttribute("sucesso", salvo.getNome() + (novo ? " cadastrado(a)" : " atualizado(a)") + " com sucesso.");
            return "redirect:/clientes";
        } catch (RegraNegocioException e) {
            model.addAttribute("erro", e.getMessage());
            return "clientes/form";
        }
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes avisos) {
        try {
            clienteService.excluir(id);
            avisos.addFlashAttribute("sucesso", "Cliente excluído.");
        } catch (RegraNegocioException e) {
            avisos.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/clientes";
    }
}
