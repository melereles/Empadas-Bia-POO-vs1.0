package br.com.empadasdabia.empadasweb.controller;

import br.com.empadasdabia.empadasweb.service.RecursoNaoEncontradoException;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseStatus;

/** Comportamentos comuns a todos os Controllers. */
@ControllerAdvice
public class ConfiguracaoGlobalController {

    /** Tira espaços das pontas de todo texto digitado; campo vazio vira null. */
    @InitBinder
    public void configurarBinder(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
    }

    /** Registro inexistente na URL (ex.: /clientes/999/editar) mostra a página 404. */
    @ExceptionHandler(RecursoNaoEncontradoException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public String naoEncontrado(RecursoNaoEncontradoException e, Model model) {
        model.addAttribute("status", 404);
        model.addAttribute("mensagem", e.getMessage());
        return "error";
    }
}
