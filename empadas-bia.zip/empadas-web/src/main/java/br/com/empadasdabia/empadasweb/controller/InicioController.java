package br.com.empadasdabia.empadasweb.controller;

import br.com.empadasdabia.empadasweb.service.ClienteService;
import br.com.empadasdabia.empadasweb.service.DashboardService;
import br.com.empadasdabia.empadasweb.service.PedidoService;
import br.com.empadasdabia.empadasweb.service.ProdutoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/** Painel inicial com o resumo do dia. */
@Controller
public class InicioController {

    private final DashboardService dashboardService;
    private final PedidoService pedidoService;
    private final ClienteService clienteService;
    private final ProdutoService produtoService;

    public InicioController(DashboardService dashboardService, PedidoService pedidoService,
                            ClienteService clienteService, ProdutoService produtoService) {
        this.dashboardService = dashboardService;
        this.pedidoService = pedidoService;
        this.clienteService = clienteService;
        this.produtoService = produtoService;
    }

    @GetMapping("/")
    public String inicio(Model model) {
        model.addAttribute("pedidosHoje", dashboardService.pedidosDeHoje());
        model.addAttribute("pendentesHoje", dashboardService.pendentesDeHoje());
        model.addAttribute("faturamentoMes", dashboardService.faturamentoDoMes());
        model.addAttribute("totalClientes", clienteService.contar());
        model.addAttribute("produtosAtivos", produtoService.contarAtivos());
        model.addAttribute("produtosTotal", produtoService.contarTodos());
        model.addAttribute("ultimosPedidos", pedidoService.listarRecentes());
        model.addAttribute("maisPedidas", dashboardService.maisPedidasDaSemana(3));
        return "index";
    }
}
