package br.com.empadasdabia.empadasweb.controller;

import br.com.empadasdabia.empadasweb.dto.PedidoForm;
import br.com.empadasdabia.empadasweb.model.Pedido;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import br.com.empadasdabia.empadasweb.service.ClienteService;
import br.com.empadasdabia.empadasweb.service.PedidoService;
import br.com.empadasdabia.empadasweb.service.ProdutoService;
import br.com.empadasdabia.empadasweb.service.RegraNegocioException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Recebe as requisições de /pedidos e chama o PedidoService. */
@Controller
@RequestMapping("/pedidos")
public class PedidoController {

    private final PedidoService pedidoService;
    private final ClienteService clienteService;
    private final ProdutoService produtoService;

    public PedidoController(PedidoService pedidoService, ClienteService clienteService,
                            ProdutoService produtoService) {
        this.pedidoService = pedidoService;
        this.clienteService = clienteService;
        this.produtoService = produtoService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String cliente,
                         @RequestParam(required = false) StatusPedido status, Model model) {
        model.addAttribute("pedidos", pedidoService.listar(cliente, status));
        model.addAttribute("cliente", cliente);
        model.addAttribute("statusSelecionado", status);
        model.addAttribute("statusOpcoes", StatusPedido.values());
        return "pedidos/lista";
    }

    @GetMapping("/{id}")
    public String detalhes(@PathVariable Long id, Model model) {
        model.addAttribute("pedido", pedidoService.buscarPorId(id));
        return "pedidos/detalhe";
    }

    @GetMapping("/novo")
    public String novo(@RequestParam(required = false) Long cliente, Model model) {
        PedidoForm form = new PedidoForm();
        form.setClienteId(cliente);
        return abrirFormulario(form, model);
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model, RedirectAttributes avisos) {
        try {
            return abrirFormulario(pedidoService.montarFormulario(id), model);
        } catch (RegraNegocioException e) {
            avisos.addFlashAttribute("erro", e.getMessage());
            return "redirect:/pedidos/" + id;
        }
    }

    @PostMapping("/salvar")
    public String salvar(@ModelAttribute("form") PedidoForm form, Model model, RedirectAttributes avisos) {
        try {
            boolean novo = form.getId() == null;
            Pedido pedido = pedidoService.salvar(form);
            avisos.addFlashAttribute("sucesso", "Pedido " + String.format("#%03d", pedido.getId())
                    + (novo ? " registrado" : " atualizado") + " com sucesso.");
            return "redirect:/pedidos/" + pedido.getId();
        } catch (RegraNegocioException e) {
            model.addAttribute("erro", e.getMessage());
            return abrirFormulario(form, model);
        }
    }

    @PostMapping("/{id}/entregar")
    public String entregar(@PathVariable Long id, RedirectAttributes avisos) {
        try {
            pedidoService.marcarComoEntregue(id);
            avisos.addFlashAttribute("sucesso", "Pedido marcado como entregue.");
        } catch (RegraNegocioException e) {
            avisos.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }

    @PostMapping("/{id}/cancelar")
    public String cancelar(@PathVariable Long id, RedirectAttributes avisos) {
        try {
            pedidoService.cancelar(id);
            avisos.addFlashAttribute("sucesso", "Pedido cancelado. Ele continua no histórico.");
        } catch (RegraNegocioException e) {
            avisos.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/pedidos/" + id;
    }

    private String abrirFormulario(PedidoForm form, Model model) {
        model.addAttribute("form", form);
        model.addAttribute("clientes", clienteService.listar(null));
        model.addAttribute("cardapio", produtoService.cardapioParaPedido(form.getQuantidades().keySet()));
        return "pedidos/form";
    }
}
