package br.com.empadasdabia.empadasweb.controller;

import br.com.empadasdabia.empadasweb.model.Produto;
import br.com.empadasdabia.empadasweb.service.CategoriaService;
import br.com.empadasdabia.empadasweb.service.ProdutoService;
import br.com.empadasdabia.empadasweb.service.RegraNegocioException;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Recebe as requisições de /produtos e chama o ProdutoService. */
@Controller
@RequestMapping("/produtos")
public class ProdutoController {

    private final ProdutoService produtoService;
    private final CategoriaService categoriaService;

    public ProdutoController(ProdutoService produtoService, CategoriaService categoriaService) {
        this.produtoService = produtoService;
        this.categoriaService = categoriaService;
    }

    @GetMapping
    public String listar(@RequestParam(required = false) String busca,
                         @RequestParam(required = false) Long categoria, Model model) {
        model.addAttribute("produtos", produtoService.listar(busca, categoria));
        model.addAttribute("categorias", categoriaService.listarTodas());
        model.addAttribute("busca", busca);
        model.addAttribute("categoriaSelecionada", categoria);
        return "produtos/lista";
    }

    @GetMapping("/novo")
    public String novo(Model model) {
        return abrirFormulario(new Produto(), model);
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        return abrirFormulario(produtoService.buscarPorId(id), model);
    }

    @PostMapping("/salvar")
    public String salvar(@Valid @ModelAttribute("produto") Produto produto, BindingResult erros,
                         @RequestParam(value = "foto", required = false) MultipartFile foto,
                         Model model, RedirectAttributes avisos) {
        if (erros.hasErrors()) {
            return abrirFormulario(produto, model);
        }
        try {
            boolean novo = produto.getId() == null;
            Produto salvo = produtoService.salvar(produto, foto);
            avisos.addFlashAttribute("sucesso", "\"" + salvo.getNome() + "\" "
                    + (novo ? "cadastrado" : "atualizado") + " com sucesso.");
            return "redirect:/produtos";
        } catch (RegraNegocioException e) {
            model.addAttribute("erro", e.getMessage());
            return abrirFormulario(produto, model);
        }
    }

    @PostMapping("/{id}/ativo")
    public String alternarAtivo(@PathVariable Long id, RedirectAttributes avisos) {
        Produto produto = produtoService.alternarAtivo(id);
        avisos.addFlashAttribute("sucesso", "\"" + produto.getNome() + "\" "
                + (produto.isAtivo() ? "voltou ao cardápio." : "foi desativado e saiu do cardápio."));
        return "redirect:/produtos";
    }

    @PostMapping("/{id}/excluir")
    public String excluir(@PathVariable Long id, RedirectAttributes avisos) {
        try {
            produtoService.excluir(id);
            avisos.addFlashAttribute("sucesso", "Produto excluído.");
        } catch (RegraNegocioException e) {
            avisos.addFlashAttribute("erro", e.getMessage());
        }
        return "redirect:/produtos";
    }

    private String abrirFormulario(Produto produto, Model model) {
        model.addAttribute("produto", produto);
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "produtos/form";
    }
}
