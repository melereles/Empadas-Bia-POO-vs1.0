package br.com.empadasdabia.empadasweb.dto;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Dados enviados pelo formulário de pedido.
 * As quantidades chegam como quantidades[idDoProduto]=valor, e o Spring monta o Map sozinho.
 */
public class PedidoForm {

    private Long id;
    private Long clienteId;
    private String observacao;
    private Map<Long, Integer> quantidades = new LinkedHashMap<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }

    public Map<Long, Integer> getQuantidades() { return quantidades; }
    public void setQuantidades(Map<Long, Integer> quantidades) { this.quantidades = quantidades; }

    /** Quantidade já escolhida para um produto (0 quando não está no pedido). */
    public int quantidadeDe(Long produtoId) {
        Integer qtd = quantidades.get(produtoId);
        return qtd == null ? 0 : qtd;
    }
}
