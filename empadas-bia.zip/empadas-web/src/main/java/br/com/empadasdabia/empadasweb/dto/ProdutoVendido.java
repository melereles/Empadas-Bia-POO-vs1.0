package br.com.empadasdabia.empadasweb.dto;

import br.com.empadasdabia.empadasweb.model.Produto;

/** Linha do ranking "Mais pedidas da semana" no painel inicial. */
public record ProdutoVendido(Produto produto, long unidades) {
}
