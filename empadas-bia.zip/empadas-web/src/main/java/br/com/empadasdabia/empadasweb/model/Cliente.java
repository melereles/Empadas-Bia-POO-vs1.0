package br.com.empadasdabia.empadasweb.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.Objects;

/** Cliente da Empadas da Bia. O endereço fica na própria tabela (um endereço por cliente). */
@Entity
@Table(name = "cliente")
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Informe o nome")
    @Size(max = 100, message = "O nome aceita no máximo 100 caracteres")
    @Column(nullable = false, length = 100)
    private String nome;

    /** Guardado só com números, ex.: 47998123344 */
    @NotBlank(message = "Informe o telefone")
    @Pattern(regexp = "\\d{10,11}", message = "Telefone inválido. Informe DDD + número, ex.: (47) 99812-3344")
    @Column(nullable = false, length = 15)
    private String telefone;

    @Email(message = "E-mail inválido. Exemplo: nome@email.com")
    @Size(max = 100, message = "O e-mail aceita no máximo 100 caracteres")
    @Column(length = 100)
    private String email;

    /** Guardado só com números, ex.: 89201000 */
    @Pattern(regexp = "\\d{8}", message = "CEP inválido. Informe os 8 números, ex.: 89201-000")
    @Column(length = 8)
    private String cep;

    @Size(max = 120, message = "O logradouro aceita no máximo 120 caracteres")
    @Column(length = 120)
    private String logradouro;

    @Size(max = 10, message = "O número aceita no máximo 10 caracteres")
    @Column(length = 10)
    private String numero;

    @Size(max = 60, message = "O bairro aceita no máximo 60 caracteres")
    @Column(length = 60)
    private String bairro;

    @Size(max = 60, message = "A cidade aceita no máximo 60 caracteres")
    @Column(length = 60)
    private String cidade;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getTelefone() { return telefone; }
    /** Aceita "(47) 99812-3344" e guarda apenas os números. */
    public void setTelefone(String telefone) { this.telefone = somenteNumeros(telefone); }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCep() { return cep; }
    /** Aceita "89201-000" e guarda apenas os números. */
    public void setCep(String cep) { this.cep = somenteNumeros(cep); }

    public String getLogradouro() { return logradouro; }
    public void setLogradouro(String logradouro) { this.logradouro = logradouro; }

    public String getNumero() { return numero; }
    public void setNumero(String numero) { this.numero = numero; }

    public String getBairro() { return bairro; }
    public void setBairro(String bairro) { this.bairro = bairro; }

    public String getCidade() { return cidade; }
    public void setCidade(String cidade) { this.cidade = cidade; }

    /** Monta o endereço em uma linha, ignorando partes não preenchidas. */
    public String getEnderecoCompleto() {
        StringBuilder sb = new StringBuilder();
        if (temTexto(logradouro)) {
            sb.append(logradouro);
            if (temTexto(numero)) {
                sb.append(", ").append(numero);
            }
        }
        if (temTexto(bairro)) {
            sb.append(sb.isEmpty() ? "" : " – ").append(bairro);
        }
        if (temTexto(cidade)) {
            sb.append(sb.isEmpty() ? "" : " – ").append(cidade);
        }
        return sb.isEmpty() ? "Endereço não informado" : sb.toString();
    }

    private static boolean temTexto(String valor) {
        return valor != null && !valor.isBlank();
    }

    private static String somenteNumeros(String valor) {
        if (valor == null) {
            return null;
        }
        String numeros = valor.replaceAll("\\D", "");
        return numeros.isEmpty() ? null : numeros;
    }

    @Override
    public boolean equals(Object outro) {
        return outro instanceof Cliente c && id != null && id.equals(c.id);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return nome;
    }
}
