package br.com.empadasdabia.empadasweb.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Pedido feito por um cliente. Contém um ou mais itens.
 * O total não é coluna: é calculado a partir dos itens (calcularTotal()).
 */
@Entity
@Table(name = "pedido")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "cliente_id", nullable = false)
    private Cliente cliente;

    @Column(nullable = false)
    private LocalDateTime dataPedido;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private StatusPedido status = StatusPedido.PENDENTE;

    @Size(max = 255, message = "A observação aceita no máximo 255 caracteres")
    @Column(length = 255)
    private String observacao;

    /** cascade = ALL: salvar o pedido salva os itens juntos; orphanRemoval apaga o item removido. */
    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id")
    private List<ItemPedido> itens = new ArrayList<>();

    /** Adiciona um produto. Se ele já estiver no pedido, apenas soma a quantidade. */
    public void adicionarItem(Produto produto, int quantidade) {
        if (quantidade <= 0) {
            throw new IllegalArgumentException("A quantidade deve ser maior que zero.");
        }
        for (ItemPedido item : itens) {
            if (item.getProduto().equals(produto)) {
                item.setQuantidade(item.getQuantidade() + quantidade);
                return;
            }
        }
        itens.add(new ItemPedido(this, produto, quantidade));
    }

    /** Item já existente deste produto, ou null. */
    public ItemPedido itemDoProduto(Long produtoId) {
        for (ItemPedido item : itens) {
            if (item.getProduto().getId().equals(produtoId)) {
                return item;
            }
        }
        return null;
    }

    /** Remove os itens cujos produtos não estão na lista informada (usado na edição). */
    public void manterSomenteProdutos(Set<Long> produtoIds) {
        itens.removeIf(item -> !produtoIds.contains(item.getProduto().getId()));
    }

    /** Total = soma dos subtotais dos itens. */
    public BigDecimal calcularTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (ItemPedido item : itens) {
            total = total.add(item.getSubtotal());
        }
        return total;
    }

    public int getQuantidadeTotalItens() {
        int total = 0;
        for (ItemPedido item : itens) {
            total += item.getQuantidade();
        }
        return total;
    }

    /** Só pedidos pendentes podem ser editados, entregues ou cancelados. */
    public boolean podeAlterarStatus() {
        return status == StatusPedido.PENDENTE;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public LocalDateTime getDataPedido() { return dataPedido; }
    public void setDataPedido(LocalDateTime dataPedido) { this.dataPedido = dataPedido; }

    public StatusPedido getStatus() { return status; }
    public void setStatus(StatusPedido status) { this.status = status; }

    public String getObservacao() { return observacao; }
    public void setObservacao(String observacao) { this.observacao = observacao; }

    /** Somente leitura: os itens são alterados pelos métodos acima. */
    public List<ItemPedido> getItens() {
        return Collections.unmodifiableList(itens);
    }
}
