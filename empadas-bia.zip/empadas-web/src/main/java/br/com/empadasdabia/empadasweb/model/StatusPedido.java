package br.com.empadasdabia.empadasweb.model;

/** Situações possíveis de um pedido. Gravado no banco pelo nome (@Enumerated(STRING)). */
public enum StatusPedido {

    PENDENTE("Pendente"),
    ENTREGUE("Entregue"),
    CANCELADO("Cancelado");

    private final String descricao;

    StatusPedido(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
