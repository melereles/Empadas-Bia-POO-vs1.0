package br.com.empadasdabia.empadasweb.repository;

import br.com.empadasdabia.empadasweb.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/** O JpaRepository já entrega findAll, findById, save e deleteById. Os demais métodos o Spring Data gera pelo nome. */
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {

    List<Categoria> findAllByOrderByNomeAsc();

    boolean existsByNomeIgnoreCase(String nome);

    boolean existsByNomeIgnoreCaseAndIdNot(String nome, Long id);
}
