package br.com.empadasdabia.empadasweb.repository;

import br.com.empadasdabia.empadasweb.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    List<Cliente> findAllByOrderByNomeAsc();

    /** Busca por parte do nome, do e-mail ou do telefone. */
    @Query("""
            select c from Cliente c
            where lower(c.nome) like lower(concat('%', :termo, '%'))
               or lower(c.email) like lower(concat('%', :termo, '%'))
               or c.telefone like concat('%', :termo, '%')
            order by c.nome
            """)
    List<Cliente> buscar(@Param("termo") String termo);
}
