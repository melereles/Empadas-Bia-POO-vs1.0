package br.com.empadasdabia.empadasweb.repository;

import br.com.empadasdabia.empadasweb.model.ItemPedido;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface ItemPedidoRepository extends JpaRepository<ItemPedido, Long> {

    boolean existsByProdutoId(Long produtoId);

    /** Soma de quantidade x preço dos pedidos não cancelados a partir de uma data. */
    @Query("""
            select coalesce(sum(i.precoUnitario * i.quantidade), 0)
            from ItemPedido i
            where i.pedido.dataPedido >= :inicio and i.pedido.status <> :ignorar
            """)
    BigDecimal somarVendasDesde(@Param("inicio") LocalDateTime inicio, @Param("ignorar") StatusPedido ignorar);

    /** [produtoId, unidades vendidas], do mais vendido para o menos vendido. */
    @Query("""
            select i.produto.id, sum(i.quantidade)
            from ItemPedido i
            where i.pedido.dataPedido >= :inicio and i.pedido.status <> :ignorar
            group by i.produto.id
            order by sum(i.quantidade) desc
            """)
    List<Object[]> rankingDeVendasDesde(@Param("inicio") LocalDateTime inicio, @Param("ignorar") StatusPedido ignorar);
}
