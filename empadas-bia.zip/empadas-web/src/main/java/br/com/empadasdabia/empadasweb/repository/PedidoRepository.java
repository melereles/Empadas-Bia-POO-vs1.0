package br.com.empadasdabia.empadasweb.repository;

import br.com.empadasdabia.empadasweb.model.Pedido;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {

    /** Filtros opcionais por nome do cliente e status; mais recentes primeiro. */
    @Query("""
            select p from Pedido p
            where (:cliente is null or lower(p.cliente.nome) like lower(concat('%', :cliente, '%')))
              and (:status is null or p.status = :status)
            order by p.dataPedido desc, p.id desc
            """)
    List<Pedido> buscar(@Param("cliente") String cliente, @Param("status") StatusPedido status);

    List<Pedido> findTop5ByOrderByDataPedidoDescIdDesc();

    boolean existsByClienteId(Long clienteId);

    long countByClienteId(Long clienteId);

    long countByDataPedidoGreaterThanEqualAndStatusNot(LocalDateTime inicio, StatusPedido status);

    long countByDataPedidoGreaterThanEqualAndStatus(LocalDateTime inicio, StatusPedido status);
}
