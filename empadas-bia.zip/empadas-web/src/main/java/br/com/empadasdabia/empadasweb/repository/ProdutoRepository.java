package br.com.empadasdabia.empadasweb.repository;

import br.com.empadasdabia.empadasweb.model.Produto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {

    /** Filtros opcionais: parâmetro nulo não filtra. */
    @Query("""
            select p from Produto p
            where (:nome is null or lower(p.nome) like lower(concat('%', :nome, '%')))
              and (:categoriaId is null or p.categoria.id = :categoriaId)
            order by p.categoria.nome, p.nome
            """)
    List<Produto> buscar(@Param("nome") String nome, @Param("categoriaId") Long categoriaId);

    /** Cardápio do Novo Pedido: somente produtos ativos. */
    List<Produto> findByAtivoTrueOrderByCategoriaNomeAscNomeAsc();

    boolean existsByCategoriaId(Long categoriaId);

    long countByCategoriaId(Long categoriaId);

    long countByAtivoTrue();
}
