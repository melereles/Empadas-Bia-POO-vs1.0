package br.com.empadasdabia.empadasweb.service;

import br.com.empadasdabia.empadasweb.model.Categoria;
import br.com.empadasdabia.empadasweb.repository.CategoriaRepository;
import br.com.empadasdabia.empadasweb.repository.ProdutoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** Regras de negócio de Categoria. É a única porta de entrada para o CategoriaRepository. */
@Service
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;
    private final ProdutoRepository produtoRepository;

    public CategoriaService(CategoriaRepository categoriaRepository, ProdutoRepository produtoRepository) {
        this.categoriaRepository = categoriaRepository;
        this.produtoRepository = produtoRepository;
    }

    public List<Categoria> listarTodas() {
        return categoriaRepository.findAllByOrderByNomeAsc();
    }

    public Categoria buscarPorId(Long id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Categoria não encontrada."));
    }

    /** Cadastra (id nulo) ou atualiza (id preenchido). O nome não pode se repetir. */
    @Transactional
    public Categoria salvar(Categoria dados) {
        boolean nomeRepetido = dados.getId() == null
                ? categoriaRepository.existsByNomeIgnoreCase(dados.getNome())
                : categoriaRepository.existsByNomeIgnoreCaseAndIdNot(dados.getNome(), dados.getId());
        if (nomeRepetido) {
            throw new RegraNegocioException("Já existe uma categoria chamada \"" + dados.getNome() + "\".");
        }
        Categoria categoria = dados.getId() == null ? new Categoria() : buscarPorId(dados.getId());
        categoria.setNome(dados.getNome());
        categoria.setDescricao(dados.getDescricao());
        return categoriaRepository.save(categoria);
    }

    /** Não exclui categoria que ainda tem produtos. */
    @Transactional
    public void excluir(Long id) {
        Categoria categoria = buscarPorId(id);
        long produtos = produtoRepository.countByCategoriaId(id);
        if (produtos > 0) {
            throw new RegraNegocioException("Não é possível excluir \"" + categoria.getNome()
                    + "\": a categoria possui " + produtos + " produto(s).");
        }
        categoriaRepository.delete(categoria);
    }
}
