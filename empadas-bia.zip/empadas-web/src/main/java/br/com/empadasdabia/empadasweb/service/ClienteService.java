package br.com.empadasdabia.empadasweb.service;

import br.com.empadasdabia.empadasweb.model.Cliente;
import br.com.empadasdabia.empadasweb.repository.ClienteRepository;
import br.com.empadasdabia.empadasweb.repository.PedidoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/** Regras de negócio de Cliente. */
@Service
public class ClienteService {

    private final ClienteRepository clienteRepository;
    private final PedidoRepository pedidoRepository;

    public ClienteService(ClienteRepository clienteRepository, PedidoRepository pedidoRepository) {
        this.clienteRepository = clienteRepository;
        this.pedidoRepository = pedidoRepository;
    }

    /** Sem termo lista todos; com termo busca por nome, e-mail ou telefone. */
    public List<Cliente> listar(String termo) {
        if (termo == null || termo.isBlank()) {
            return clienteRepository.findAllByOrderByNomeAsc();
        }
        String busca = termo.trim();
        // "(47) 9981" vira "479981" para achar telefones guardados só com números
        if (busca.matches("[\\d\\s()+-]+")) {
            busca = busca.replaceAll("\\D", "");
        }
        return clienteRepository.buscar(busca);
    }

    public Cliente buscarPorId(Long id) {
        return clienteRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Cliente não encontrado."));
    }

    public long contar() {
        return clienteRepository.count();
    }

    @Transactional
    public Cliente salvar(Cliente dados) {
        Cliente cliente = dados.getId() == null ? new Cliente() : buscarPorId(dados.getId());
        cliente.setNome(dados.getNome());
        cliente.setTelefone(dados.getTelefone());
        cliente.setEmail(dados.getEmail());
        cliente.setCep(dados.getCep());
        cliente.setLogradouro(dados.getLogradouro());
        cliente.setNumero(dados.getNumero());
        cliente.setBairro(dados.getBairro());
        cliente.setCidade(dados.getCidade());
        return clienteRepository.save(cliente);
    }

    /** Cliente com pedidos não é excluído, para não perder o histórico de vendas. */
    @Transactional
    public void excluir(Long id) {
        Cliente cliente = buscarPorId(id);
        if (pedidoRepository.existsByClienteId(id)) {
            throw new RegraNegocioException("Não é possível excluir " + cliente.getNome()
                    + ": o cliente possui pedidos no histórico.");
        }
        clienteRepository.delete(cliente);
    }
}
