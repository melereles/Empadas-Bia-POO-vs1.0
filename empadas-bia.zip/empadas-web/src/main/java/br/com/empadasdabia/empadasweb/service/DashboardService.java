package br.com.empadasdabia.empadasweb.service;

import br.com.empadasdabia.empadasweb.dto.ProdutoVendido;
import br.com.empadasdabia.empadasweb.model.Produto;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import br.com.empadasdabia.empadasweb.repository.ItemPedidoRepository;
import br.com.empadasdabia.empadasweb.repository.PedidoRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Reúne os números exibidos no painel inicial. */
@Service
public class DashboardService {

    private final PedidoRepository pedidoRepository;
    private final ItemPedidoRepository itemPedidoRepository;
    private final ProdutoService produtoService;

    public DashboardService(PedidoRepository pedidoRepository, ItemPedidoRepository itemPedidoRepository,
                            ProdutoService produtoService) {
        this.pedidoRepository = pedidoRepository;
        this.itemPedidoRepository = itemPedidoRepository;
        this.produtoService = produtoService;
    }

    /** Pedidos de hoje que não foram cancelados. */
    public long pedidosDeHoje() {
        return pedidoRepository.countByDataPedidoGreaterThanEqualAndStatusNot(inicioDeHoje(), StatusPedido.CANCELADO);
    }

    public long pendentesDeHoje() {
        return pedidoRepository.countByDataPedidoGreaterThanEqualAndStatus(inicioDeHoje(), StatusPedido.PENDENTE);
    }

    /** Soma dos pedidos do mês atual, sem os cancelados. */
    public BigDecimal faturamentoDoMes() {
        LocalDateTime inicioDoMes = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        return itemPedidoRepository.somarVendasDesde(inicioDoMes, StatusPedido.CANCELADO);
    }

    /** Os produtos com mais unidades vendidas nos últimos 7 dias. */
    public List<ProdutoVendido> maisPedidasDaSemana(int limite) {
        LocalDateTime seteDiasAtras = LocalDate.now().minusDays(6).atStartOfDay();
        List<Object[]> ranking = itemPedidoRepository.rankingDeVendasDesde(seteDiasAtras, StatusPedido.CANCELADO)
                .stream().limit(limite).toList();
        List<Long> ids = ranking.stream().map(linha -> (Long) linha[0]).toList();
        Map<Long, Produto> produtos = produtoService.buscarPorIds(ids).stream()
                .collect(Collectors.toMap(Produto::getId, Function.identity()));
        List<ProdutoVendido> resultado = new ArrayList<>();
        for (Object[] linha : ranking) {
            resultado.add(new ProdutoVendido(produtos.get((Long) linha[0]), ((Number) linha[1]).longValue()));
        }
        return resultado;
    }

    private static LocalDateTime inicioDeHoje() {
        return LocalDate.now().atStartOfDay();
    }
}
