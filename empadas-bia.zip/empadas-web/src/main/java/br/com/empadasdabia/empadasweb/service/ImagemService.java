package br.com.empadasdabia.empadasweb.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Grava as fotos enviadas no cadastro de produto na pasta de uploads. */
@Service
public class ImagemService {

    private static final Set<String> EXTENSOES = Set.of("png", "jpg", "jpeg", "webp", "gif");

    private final Path pasta;

    public ImagemService(@Value("${app.uploads.pasta:uploads}") String pasta) {
        this.pasta = Path.of(pasta).toAbsolutePath().normalize();
    }

    /** Salva o arquivo e devolve o caminho público (ex.: /uploads/3f2a....png). */
    public String salvar(MultipartFile arquivo) {
        String nomeOriginal = arquivo.getOriginalFilename() == null ? "" : arquivo.getOriginalFilename();
        int ponto = nomeOriginal.lastIndexOf('.');
        String extensao = ponto < 0 ? "" : nomeOriginal.substring(ponto + 1).toLowerCase(Locale.ROOT);
        if (!EXTENSOES.contains(extensao)) {
            throw new RegraNegocioException("A imagem deve ser PNG, JPG, WEBP ou GIF.");
        }
        String nome = UUID.randomUUID() + "." + extensao;
        try (InputStream entrada = arquivo.getInputStream()) {
            Files.createDirectories(pasta);
            Files.copy(entrada, pasta.resolve(nome), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new RegraNegocioException("Não foi possível salvar a imagem.");
        }
        return "/uploads/" + nome;
    }

    public Path getPasta() {
        return pasta;
    }
}
