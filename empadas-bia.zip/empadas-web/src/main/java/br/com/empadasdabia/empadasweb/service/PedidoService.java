package br.com.empadasdabia.empadasweb.service;

import br.com.empadasdabia.empadasweb.dto.PedidoForm;
import br.com.empadasdabia.empadasweb.model.Cliente;
import br.com.empadasdabia.empadasweb.model.ItemPedido;
import br.com.empadasdabia.empadasweb.model.Pedido;
import br.com.empadasdabia.empadasweb.model.Produto;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import br.com.empadasdabia.empadasweb.repository.PedidoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Regras do fluxo de pedidos: montar, validar, salvar e mudar o status. */
@Service
public class PedidoService {

    private static final int MAX_QUANTIDADE = 999;

    private final PedidoRepository pedidoRepository;
    private final ClienteService clienteService;
    private final ProdutoService produtoService;

    public PedidoService(PedidoRepository pedidoRepository, ClienteService clienteService,
                         ProdutoService produtoService) {
        this.pedidoRepository = pedidoRepository;
        this.clienteService = clienteService;
        this.produtoService = produtoService;
    }

    public List<Pedido> listar(String cliente, StatusPedido status) {
        String filtro = cliente == null || cliente.isBlank() ? null : cliente.trim();
        return pedidoRepository.buscar(filtro, status);
    }

    public List<Pedido> listarRecentes() {
        return pedidoRepository.findTop5ByOrderByDataPedidoDescIdDesc();
    }

    public Pedido buscarPorId(Long id) {
        return pedidoRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Pedido não encontrado."));
    }

    /** Preenche o formulário de edição com os dados de um pedido salvo. */
    public PedidoForm montarFormulario(Long id) {
        Pedido pedido = buscarPorId(id);
        exigirPendente(pedido, "editado");
        PedidoForm form = new PedidoForm();
        form.setId(pedido.getId());
        form.setClienteId(pedido.getCliente().getId());
        form.setObservacao(pedido.getObservacao());
        for (ItemPedido item : pedido.getItens()) {
            form.getQuantidades().put(item.getProduto().getId(), item.getQuantidade());
        }
        return form;
    }

    /**
     * Cria (id nulo) ou edita um pedido pendente.
     * Regras: precisa de cliente e de pelo menos um item. Itens novos usam o preço atual
     * do produto; itens que já estavam no pedido mantêm o preço da venda original.
     * Tudo em uma transação: pedido e itens são gravados juntos ou nada é gravado.
     */
    @Transactional
    public Pedido salvar(PedidoForm form) {
        if (form.getClienteId() == null) {
            throw new RegraNegocioException("Selecione o cliente do pedido.");
        }
        Map<Long, Integer> escolhidos = new LinkedHashMap<>();
        form.getQuantidades().forEach((produtoId, qtd) -> {
            if (produtoId != null && qtd != null && qtd > 0) {
                if (qtd > MAX_QUANTIDADE) {
                    throw new RegraNegocioException("A quantidade máxima por produto é " + MAX_QUANTIDADE + ".");
                }
                escolhidos.put(produtoId, qtd);
            }
        });
        if (escolhidos.isEmpty()) {
            throw new RegraNegocioException("Adicione pelo menos um produto ao pedido.");
        }
        if (form.getObservacao() != null && form.getObservacao().length() > 255) {
            throw new RegraNegocioException("A observação aceita no máximo 255 caracteres.");
        }

        Cliente cliente = clienteService.buscarPorId(form.getClienteId());
        Pedido pedido;
        if (form.getId() == null) {
            pedido = new Pedido();
            pedido.setDataPedido(LocalDateTime.now().withNano(0));
            pedido.setStatus(StatusPedido.PENDENTE);
        } else {
            pedido = buscarPorId(form.getId());
            exigirPendente(pedido, "editado");
        }
        pedido.setCliente(cliente);
        pedido.setObservacao(form.getObservacao());

        pedido.manterSomenteProdutos(escolhidos.keySet());
        for (Map.Entry<Long, Integer> escolha : escolhidos.entrySet()) {
            ItemPedido existente = pedido.itemDoProduto(escolha.getKey());
            if (existente != null) {
                existente.setQuantidade(escolha.getValue());
            } else {
                Produto produto = produtoService.buscarPorId(escolha.getKey());
                if (!produto.isAtivo()) {
                    throw new RegraNegocioException("\"" + produto.getNome() + "\" está inativo e não pode ser vendido.");
                }
                pedido.adicionarItem(produto, escolha.getValue());
            }
        }
        return pedidoRepository.save(pedido);
    }

    @Transactional
    public Pedido marcarComoEntregue(Long id) {
        return alterarStatus(id, StatusPedido.ENTREGUE, "entregue");
    }

    /** Cancelamento substitui a exclusão: o pedido continua no histórico de vendas. */
    @Transactional
    public Pedido cancelar(Long id) {
        return alterarStatus(id, StatusPedido.CANCELADO, "cancelado");
    }

    private Pedido alterarStatus(Long id, StatusPedido novoStatus, String acao) {
        Pedido pedido = buscarPorId(id);
        exigirPendente(pedido, acao);
        pedido.setStatus(novoStatus);
        return pedido;
    }

    private void exigirPendente(Pedido pedido, String acao) {
        if (!pedido.podeAlterarStatus()) {
            throw new RegraNegocioException("Apenas pedidos pendentes podem ser " + acao + "s. Este pedido está "
                    + pedido.getStatus().getDescricao().toLowerCase() + ".");
        }
    }
}
