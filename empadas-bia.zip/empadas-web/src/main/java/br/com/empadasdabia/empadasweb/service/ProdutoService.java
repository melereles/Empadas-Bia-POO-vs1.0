package br.com.empadasdabia.empadasweb.service;

import br.com.empadasdabia.empadasweb.model.Produto;
import br.com.empadasdabia.empadasweb.repository.ItemPedidoRepository;
import br.com.empadasdabia.empadasweb.repository.ProdutoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Regras de negócio de Produto. */
@Service
public class ProdutoService {

    private final ProdutoRepository produtoRepository;
    private final ItemPedidoRepository itemPedidoRepository;
    private final CategoriaService categoriaService;
    private final ImagemService imagemService;

    public ProdutoService(ProdutoRepository produtoRepository, ItemPedidoRepository itemPedidoRepository,
                          CategoriaService categoriaService, ImagemService imagemService) {
        this.produtoRepository = produtoRepository;
        this.itemPedidoRepository = itemPedidoRepository;
        this.categoriaService = categoriaService;
        this.imagemService = imagemService;
    }

    /** Todos os produtos (ativos e inativos), com filtros opcionais. */
    public List<Produto> listar(String nome, Long categoriaId) {
        String filtro = nome == null || nome.isBlank() ? null : nome.trim();
        return produtoRepository.buscar(filtro, categoriaId);
    }

    public Produto buscarPorId(Long id) {
        return produtoRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Produto não encontrado."));
    }

    public List<Produto> buscarPorIds(Collection<Long> ids) {
        return produtoRepository.findAllById(ids);
    }

    public long contarTodos() {
        return produtoRepository.count();
    }

    public long contarAtivos() {
        return produtoRepository.countByAtivoTrue();
    }

    /**
     * Cardápio do formulário de pedido, agrupado por categoria: produtos ativos
     * e também os que já estão no pedido (mesmo que tenham sido desativados depois).
     */
    public Map<String, List<Produto>> cardapioParaPedido(Collection<Long> produtosNoPedido) {
        Map<String, List<Produto>> cardapio = new LinkedHashMap<>();
        for (Produto p : produtoRepository.buscar(null, null)) {
            if (p.isAtivo() || produtosNoPedido.contains(p.getId())) {
                cardapio.computeIfAbsent(p.getCategoria().getNome(), k -> new ArrayList<>()).add(p);
            }
        }
        return cardapio;
    }

    /**
     * Cadastra ou atualiza. A categoria é buscada pelo id para garantir que existe.
     * Se veio uma foto nova, grava; se não, mantém a anterior.
     */
    @Transactional
    public Produto salvar(Produto dados, MultipartFile foto) {
        Produto produto = dados.getId() == null ? new Produto() : buscarPorId(dados.getId());
        produto.setNome(dados.getNome());
        produto.setDescricao(dados.getDescricao());
        produto.setPreco(dados.getPreco());
        produto.setAtivo(dados.isAtivo());
        produto.setCategoria(categoriaService.buscarPorId(dados.getCategoria().getId()));
        if (foto != null && !foto.isEmpty()) {
            produto.setImagem(imagemService.salvar(foto));
        }
        return produtoRepository.save(produto);
    }

    /** Liga/desliga o produto no cardápio e devolve o produto atualizado. */
    @Transactional
    public Produto alternarAtivo(Long id) {
        Produto produto = buscarPorId(id);
        produto.setAtivo(!produto.isAtivo());
        return produto;
    }

    /** Produto que já foi vendido não pode sumir do histórico: deve ser desativado. */
    @Transactional
    public void excluir(Long id) {
        Produto produto = buscarPorId(id);
        if (itemPedidoRepository.existsByProdutoId(id)) {
            throw new RegraNegocioException("\"" + produto.getNome()
                    + "\" já aparece em pedidos e não pode ser excluído. Desative-o para tirá-lo do cardápio.");
        }
        produtoRepository.delete(produto);
    }
}
