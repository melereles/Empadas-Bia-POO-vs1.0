package br.com.empadasdabia.empadasweb.service;

/** Lançada quando o registro pedido na URL não existe (vira a página 404). */
public class RecursoNaoEncontradoException extends RuntimeException {

    public RecursoNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
