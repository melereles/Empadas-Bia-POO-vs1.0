package br.com.empadasdabia.empadasweb.service;

/** Lançada pelos Services quando uma regra de negócio impede a operação. A mensagem vai para a tela. */
public class RegraNegocioException extends RuntimeException {

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
