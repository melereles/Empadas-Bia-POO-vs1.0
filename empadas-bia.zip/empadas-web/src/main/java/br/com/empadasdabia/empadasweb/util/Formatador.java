package br.com.empadasdabia.empadasweb.util;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Formata valores para exibição. Usado nas telas Thymeleaf como ${@fmt.moeda(valor)}.
 */
@Component("fmt")
public class Formatador {

    private static final Locale BRASIL = Locale.of("pt", "BR");
    private static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final DateTimeFormatter DATA_CURTA = DateTimeFormatter.ofPattern("dd/MM HH:mm");
    private static final DateTimeFormatter DATA_EXTENSO = DateTimeFormatter.ofPattern("EEEE, dd/MM/yyyy", BRASIL);

    /** Ex.: 9.5 -> "R$ 9,50" */
    public String moeda(BigDecimal valor) {
        NumberFormat formato = NumberFormat.getCurrencyInstance(BRASIL);
        return formato.format(valor == null ? BigDecimal.ZERO : valor).replace(' ', ' ');
    }

    public String dataHora(LocalDateTime data) {
        return data == null ? "" : data.format(DATA_HORA);
    }

    public String dataCurta(LocalDateTime data) {
        return data == null ? "" : data.format(DATA_CURTA);
    }

    /** Ex.: "segunda-feira, 09/11/2026" */
    public String hojePorExtenso() {
        return LocalDate.now().format(DATA_EXTENSO);
    }

    /** Ex.: 15 -> "#015" */
    public String numeroPedido(Long id) {
        return id == null ? "Novo" : String.format("#%03d", id);
    }

    /** Ex.: 47998123344 -> "(47) 99812-3344" */
    public String telefone(String numeros) {
        if (numeros == null) {
            return "";
        }
        if (numeros.length() == 11) {
            return "(" + numeros.substring(0, 2) + ") " + numeros.substring(2, 7) + "-" + numeros.substring(7);
        }
        if (numeros.length() == 10) {
            return "(" + numeros.substring(0, 2) + ") " + numeros.substring(2, 6) + "-" + numeros.substring(6);
        }
        return numeros;
    }

    /** Ex.: 89201000 -> "89201-000" */
    public String cep(String numeros) {
        if (numeros == null || numeros.length() != 8) {
            return numeros == null ? "" : numeros;
        }
        return numeros.substring(0, 5) + "-" + numeros.substring(5);
    }
}
