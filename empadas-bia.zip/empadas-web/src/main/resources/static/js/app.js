/* Empadas da Bia Web — interações das telas (o sistema funciona mesmo sem JavaScript). */
(function () {
    'use strict';

    const moeda = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

    /* ---------- Menu lateral no celular ---------- */
    const botaoMenu = document.querySelector('[data-abrir-menu]');
    function alternarMenu(abrir) {
        document.body.classList.toggle('menu-aberto', abrir);
        if (botaoMenu) botaoMenu.setAttribute('aria-expanded', String(abrir));
    }
    if (botaoMenu) {
        botaoMenu.addEventListener('click', () => alternarMenu(!document.body.classList.contains('menu-aberto')));
    }
    document.querySelectorAll('[data-fechar-menu]').forEach(el => el.addEventListener('click', () => alternarMenu(false)));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') alternarMenu(false); });

    /* ---------- Avisos: fechar no X e sumir sozinho ---------- */
    document.querySelectorAll('.aviso').forEach(aviso => {
        const fechar = () => aviso.remove();
        aviso.querySelector('.aviso-fechar')?.addEventListener('click', fechar);
        if (aviso.classList.contains('aviso-sucesso')) setTimeout(fechar, 6000);
    });

    /* ---------- Confirmação antes de excluir / cancelar ---------- */
    const dialogo = document.getElementById('dialogo-confirmar');
    document.querySelectorAll('form[data-confirmar]').forEach(form => {
        form.addEventListener('submit', e => {
            if (form.dataset.confirmado === 'sim') return;
            e.preventDefault();
            const texto = form.dataset.confirmar;
            if (!dialogo || typeof dialogo.showModal !== 'function') {
                if (window.confirm(texto)) { form.dataset.confirmado = 'sim'; form.submit(); }
                return;
            }
            dialogo.querySelector('.dialogo-titulo').textContent = form.dataset.titulo || 'Confirmar';
            dialogo.querySelector('.dialogo-texto').textContent = texto;
            dialogo.querySelector('button[value="sim"]').textContent = form.dataset.botao || 'Confirmar';
            dialogo.returnValue = '';
            dialogo.showModal();
            dialogo.addEventListener('close', function aoFechar() {
                dialogo.removeEventListener('close', aoFechar);
                if (dialogo.returnValue === 'sim') { form.dataset.confirmado = 'sim'; form.submit(); }
            });
        });
    });

    /* ---------- Máscaras de telefone e CEP ---------- */
    function mascaraTelefone(v) {
        const d = v.replace(/\D/g, '').slice(0, 11);
        if (d.length <= 2) return d.length ? '(' + d : '';
        if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
        if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
        return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
    }
    function mascaraCep(v) {
        const d = v.replace(/\D/g, '').slice(0, 8);
        return d.length > 5 ? `${d.slice(0, 5)}-${d.slice(5)}` : d;
    }
    document.querySelectorAll('[data-mascara="telefone"]').forEach(campo => {
        campo.value = mascaraTelefone(campo.value);
        campo.addEventListener('input', () => { campo.value = mascaraTelefone(campo.value); });
    });
    document.querySelectorAll('[data-mascara="cep"]').forEach(campo => {
        campo.value = mascaraCep(campo.value);
        campo.addEventListener('input', () => {
            campo.value = mascaraCep(campo.value);
            if (campo.value.replace(/\D/g, '').length === 8) buscarCep(campo);
        });
    });

    /* Preenche o endereço pelo CEP (ViaCEP). Se a busca falhar, nada acontece. */
    let ultimoCep = '';
    function buscarCep(campo) {
        const cep = campo.value.replace(/\D/g, '');
        if (cep === ultimoCep) return;
        ultimoCep = cep;
        const ajuda = document.getElementById('cep-ajuda');
        if (ajuda) ajuda.textContent = 'Buscando endereço...';
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(r => r.ok ? r.json() : Promise.reject())
            .then(dados => {
                if (dados.erro) { if (ajuda) ajuda.textContent = 'CEP não encontrado. Preencha o endereço manualmente.'; return; }
                const preencher = (id, valor) => { const el = document.getElementById(id); if (el && valor) el.value = valor; };
                preencher('logradouro', dados.logradouro);
                preencher('bairro', dados.bairro);
                preencher('cidade', dados.localidade);
                if (ajuda) ajuda.textContent = 'Endereço preenchido pelo CEP. Confira e informe o número.';
                document.getElementById('numero')?.focus();
            })
            .catch(() => { if (ajuda) ajuda.textContent = 'Digite o CEP para preencher o endereço automaticamente.'; });
    }

    /* ---------- Pré-visualização da foto do produto ---------- */
    const campoFoto = document.getElementById('foto');
    const previa = document.getElementById('previa-foto');
    if (campoFoto && previa) {
        campoFoto.addEventListener('change', () => {
            const arquivo = campoFoto.files && campoFoto.files[0];
            if (arquivo) previa.src = URL.createObjectURL(arquivo);
        });
    }

    /* ---------- Formulário de pedido: contadores, filtros e comanda ---------- */
    const formPedido = document.getElementById('form-pedido');
    if (formPedido) {
        const itens = Array.from(formPedido.querySelectorAll('.item-cardapio'));
        const lista = document.getElementById('comanda-itens');
        const vazia = document.getElementById('comanda-vazia');
        const totais = document.querySelectorAll('[data-total]');
        const unidades = document.querySelectorAll('[data-unidades]');

        function atualizarComanda() {
            let total = 0, qtdTotal = 0;
            lista.innerHTML = '';
            itens.forEach(item => {
                const campo = item.querySelector('input');
                let qtd = parseInt(campo.value, 10);
                if (isNaN(qtd) || qtd < 0) qtd = 0;
                const preco = parseFloat(item.dataset.preco);
                item.classList.toggle('selecionado', qtd > 0);
                if (qtd > 0) {
                    total += qtd * preco;
                    qtdTotal += qtd;
                    const li = document.createElement('li');
                    const nome = document.createElement('span');
                    nome.textContent = item.dataset.nome;
                    const det = document.createElement('small');
                    det.textContent = `${qtd} × ${moeda.format(preco)}`;
                    nome.appendChild(det);
                    const sub = document.createElement('strong');
                    sub.textContent = moeda.format(qtd * preco);
                    li.append(nome, sub);
                    lista.appendChild(li);
                }
            });
            vazia.hidden = qtdTotal > 0;
            totais.forEach(el => { el.textContent = moeda.format(total); });
            unidades.forEach(el => { el.textContent = qtdTotal + (qtdTotal === 1 ? ' unidade' : ' unidades'); });
        }

        itens.forEach(item => {
            const campo = item.querySelector('input');
            item.querySelectorAll('[data-passo]').forEach(botao => {
                botao.addEventListener('click', () => {
                    const atual = parseInt(campo.value, 10) || 0;
                    campo.value = Math.min(999, Math.max(0, atual + parseInt(botao.dataset.passo, 10)));
                    atualizarComanda();
                });
            });
            campo.addEventListener('input', atualizarComanda);
        });

        // Busca por sabor e filtro por categoria
        const busca = document.getElementById('busca-sabor');
        const chips = Array.from(document.querySelectorAll('[data-filtro-categoria]'));
        let categoriaAtiva = '';
        function filtrar() {
            const termo = (busca?.value || '').trim().toLowerCase();
            document.querySelectorAll('.grupo-cardapio').forEach(grupo => {
                const daCategoria = !categoriaAtiva || grupo.dataset.categoria === categoriaAtiva;
                let visiveis = 0;
                grupo.querySelectorAll('.item-cardapio').forEach(item => {
                    const mostra = daCategoria && item.dataset.nome.toLowerCase().includes(termo);
                    item.hidden = !mostra;
                    if (mostra) visiveis++;
                });
                grupo.hidden = visiveis === 0;
            });
        }
        busca?.addEventListener('input', filtrar);
        busca?.addEventListener('keydown', e => { if (e.key === 'Enter') e.preventDefault(); });
        chips.forEach(chip => chip.addEventListener('click', () => {
            categoriaAtiva = chip.dataset.filtroCategoria;
            chips.forEach(c => c.classList.toggle('ativo', c === chip));
            filtrar();
        }));

        formPedido.addEventListener('submit', e => {
            const algum = itens.some(item => (parseInt(item.querySelector('input').value, 10) || 0) > 0);
            const cliente = document.getElementById('clienteId');
            if (!cliente.value) { e.preventDefault(); cliente.focus(); cliente.classList.add('invalido'); return; }
            if (!algum) { e.preventDefault(); vazia.classList.add('erro-campo'); vazia.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
        });

        atualizarComanda();
    }
})();
