package br.com.empadasdabia.empadasweb;

import br.com.empadasdabia.empadasweb.model.Cliente;
import br.com.empadasdabia.empadasweb.model.Pedido;
import br.com.empadasdabia.empadasweb.model.Produto;
import br.com.empadasdabia.empadasweb.model.StatusPedido;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Testes das regras que ficam no Model (não precisam do banco ligado). */
class EmpadasWebApplicationTests {

    private static Produto produto(long id, String preco) {
        Produto p = new Produto();
        p.setId(id);
        p.setNome("Produto " + id);
        p.setPreco(new BigDecimal(preco));
        return p;
    }

    @Test
    void totalDoPedidoSomaOsSubtotais() {
        Pedido pedido = new Pedido();
        pedido.adicionarItem(produto(1, "8.00"), 3);
        pedido.adicionarItem(produto(2, "8.50"), 2);
        assertEquals(new BigDecimal("41.00"), pedido.calcularTotal());
        assertEquals(5, pedido.getQuantidadeTotalItens());
    }

    @Test
    void mesmoProdutoSomaQuantidadeEmVezDeRepetirLinha() {
        Pedido pedido = new Pedido();
        Produto frango = produto(1, "8.00");
        pedido.adicionarItem(frango, 2);
        pedido.adicionarItem(frango, 3);
        assertEquals(1, pedido.getItens().size());
        assertEquals(5, pedido.getItens().getFirst().getQuantidade());
    }

    @Test
    void itemGuardaPrecoDoMomentoDaVenda() {
        Pedido pedido = new Pedido();
        Produto frango = produto(1, "8.00");
        pedido.adicionarItem(frango, 1);
        frango.setPreco(new BigDecimal("10.00"));
        assertEquals(new BigDecimal("8.00"), pedido.getItens().getFirst().getPrecoUnitario());
    }

    @Test
    void manterSomenteProdutosRemoveOsDemais() {
        Pedido pedido = new Pedido();
        pedido.adicionarItem(produto(1, "8.00"), 1);
        pedido.adicionarItem(produto(2, "9.00"), 1);
        pedido.manterSomenteProdutos(Set.of(2L));
        assertEquals(1, pedido.getItens().size());
        assertEquals(new BigDecimal("9.00"), pedido.calcularTotal());
    }

    @Test
    void soPedidoPendentePodeMudarDeStatus() {
        Pedido pedido = new Pedido();
        assertTrue(pedido.podeAlterarStatus());
        pedido.setStatus(StatusPedido.CANCELADO);
        assertFalse(pedido.podeAlterarStatus());
    }

    @Test
    void clienteGuardaTelefoneECepSoComNumeros() {
        Cliente c = new Cliente();
        c.setTelefone("(47) 99812-3344");
        c.setCep("89201-000");
        assertEquals("47998123344", c.getTelefone());
        assertEquals("89201000", c.getCep());
    }
}
